//
//  ViewController.m
//  文本特殊
//
//  Created by ZYZXNETWORK on 16/7/25.
//  Copyright © 2016年 ZYZXNETWORK. All rights reserved.
//

#import "ViewController.h"
#import "SingletonManager.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//@"U 6d4bU 8bd5"
_lable.text=    [SingletonManager replaceUnicode:@"U 6d4bU 8bd5"];

//decodeFromPercentEscapeString
    
}
- (IBAction)dsdsd:(UIButton *)sender {

    NSString *str =[NSString stringWithFormat:@"http://192.168.0.110:90/test?cont=%@",_sss.text];
   [SingletonManager GXMenulisturl:str completion:^(NSMutableDictionary *dic) {
       NSLog(@"%@",dic);
       _lable.text=dic[@"cont"];
   }];
//
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
