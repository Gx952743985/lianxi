//
//  SingletonManager.m
//  Test_singleton_ARC
//
//  Created by SuperWang on 16/1/4.
//  Copyright (c) 2016年 智游. All rights reserved.
//

#import "SingletonManager.h"

//ARC
@implementation SingletonManager
//易于外部访问
+(SingletonManager*)sharedManager
{
    static SingletonManager *manager = nil;
    
    static dispatch_once_t onceToken;
  dispatch_once(&onceToken, ^{
        manager = [[self alloc]init];
      manager.nightDay=@"0";
    });
 

    
    return manager;
}


//post请求
+(void)GXlistmessUrl:(NSString*)url  Winit:(NSDictionary*)dic  completion:(CompletionBlock)cBlock;
{
    
    // 创建请求管理者
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    //启动json解析
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
    // 请求超时时间
//    manager.requestSerializer.timeoutInterval = 30;
    [manager POST:url parameters:dic progress:^(NSProgress * uploadProgress) {
        
    } success:^(NSURLSessionDataTask *  task, id  _Nullable responseObject) {
        if (responseObject) {
            cBlock(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@%@",task,error);
    }];
    

}
//get请求
+ (void)GXMenulisturl:(NSString*)urlstr completion:(CompletionBlock)cBlock
{
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    NSString * encodedString = [urlstr stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
    NSURL *URL = [NSURL URLWithString:encodedString];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
        if (error) {
            NSLog(@"Error: %@", error);
        } else {
            
            if (responseObject) {
                cBlock(responseObject);
            }
            
        }
    }];
    
    [dataTask resume];
    
}
//取色
+(UIColor*)initcolor:(NSString*)url
{
    long red=strtol([[url substringWithRange:NSMakeRange(0, 2)]UTF8String], 0, 16);
    long green=strtol([[url substringWithRange:NSMakeRange(2, 2)]UTF8String], 0, 16);
    long blue=strtol([[url substringWithRange:NSMakeRange(4, 2)]UTF8String], 0, 16);
    UIColor *cl=[UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:1];
    return cl;
}

+(NSString*)GXinitphoneStr:(NSString*)str
{
    NSString *str1=[str substringFromIndex:7];
    NSString *str2=[str substringToIndex:3];

    return [NSString stringWithFormat:@"%@****%@",str2,str1];
}
//+(void)GXmissnsting:(NSString*)str
//{
//    [SVProgressHUD showInfoWithStatus:str];
//    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
//    [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];
////    [SVProgressHUD setBackgroundColor:HDColor(0, 0, 0, 0.8)];
////    [SVProgressHUD setForegroundColor:[UIColor whiteColor]];
//    [SVProgressHUD setFadeOutAnimationDuration:0.6];
//    [SVProgressHUD setFadeInAnimationDuration:0.6];
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0), ^{
//        [NSThread sleepForTimeInterval:1];
//        
//        
//        dispatch_async(dispatch_get_main_queue(), ^{
//            
//            [SVProgressHUD dismiss];
//        });
//    });
//    
//    
//}
//#pragma mark - 正确提示框
//+(void)SuccessWithString:(NSString *)str
//{
//    [SVProgressHUD showSuccessWithStatus:str];
//    [SVProgressHUD setFadeOutAnimationDuration:0.6];
//    [SVProgressHUD setFadeInAnimationDuration:0.6];
//    [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];
//    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0), ^{
//        [NSThread sleepForTimeInterval:1];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            
//            [SVProgressHUD dismiss];
//        });
//    });
//
//}
//#pragma mark - 错误提示框
//+(void)ErrorWithString:(NSString *)str
//{
//    [SVProgressHUD showErrorWithStatus:str];
//    [SVProgressHUD setFadeOutAnimationDuration:0.6];
//    [SVProgressHUD setFadeInAnimationDuration:0.6];
//    [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];
//    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeNone];
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0), ^{
//        [NSThread sleepForTimeInterval:1];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            [SVProgressHUD dismiss];
//            
//        });
//    });
//
//}
//+(void)GXupdatamsiistr:(NSString*)str
//{
//    [SVProgressHUD show];
//    [SVProgressHUD showWithStatus:str];
//    [SVProgressHUD setDefaultAnimationType:SVProgressHUDAnimationTypeNative];
//    //    颜色
//    [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];
//    
//    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeGradient];
//    
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0), ^{
//        
//        dispatch_async(dispatch_get_main_queue(), ^{
//            
//            
//        });
//    });
//    
//    
//    
//}
//+(void)GXendmsiistr
//{
//    [SVProgressHUD dismiss];
//    
//}



//获取存储路径
+(NSString *)getPath
{
    return [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/yujing.plist"];
}
////存文件
//+(void)write:(NSArray*)arr  filePatch:(NSString*)pact
//{
//    
//    if ([NSKeyedArchiver archiveRootObject:arr toFile:pact])
//    {
//        DLog(@"存储成功");
//    }
//    else
//    {
//        DLog(@"存储失败");
//    }
//}
//读文件
+(NSArray*)readFile:(NSString*)pact
{
    return [NSKeyedUnarchiver unarchiveObjectWithFile:pact];
}
//判断身份证
+(BOOL)GXvalidateIdentityCard: (NSString *)identityCard;
{
    BOOL flag;
    if (identityCard.length <= 0) {
        flag = NO;
        return flag;
    }
    NSString *regex2 = @"";
    switch (identityCard.length) {
        case 15:
        {
            regex2=@"^[1-9]\\d{7}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}$";
        }
            break;
            
        case 18:
        {
            regex2=@"^[1-9]\\d{5}[1-9]\\d{3}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}([0-9]|X)$";
        }
            break;
        default:
            break;
    }
    
    NSPredicate *identityCardPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex2];
    return [identityCardPredicate evaluateWithObject:identityCard];
}

-(id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}







//Unicode转UTF-8

+ (NSString *)encodeToPercentEscapeString: (NSString *) input

{
    
    // Encode all the reserved characters, per RFC 3986
    
    // (<http://www.ietf.org/rfc/rfc3986.txt>)
    
    NSString *outputStr = (NSString *)
    
    CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                            
                                            (CFStringRef)input,
                                            
                                            NULL,
                                            
                                            (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                            
                                            kCFStringEncodingUTF8));
    
    return outputStr;
    
}


+ (NSString *)decodeFromPercentEscapeString: (NSString *) input

{
    
    NSMutableString *outputStr = [NSMutableString stringWithString:input];
    
    [outputStr replaceOccurrencesOfString:@"+"
     
                               withString:@" "
     
                                  options:NSLiteralSearch
     
                                    range:NSMakeRange(0, [outputStr length])];
    
    
    
    return [outputStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
}


//Unicode转UTF-8

+ (NSString*) replaceUnicode:(NSString*)aUnicodeString

{
    
    NSString *tempStr1 = [aUnicodeString stringByReplacingOccurrencesOfString:@"\\u" withString:@"\\U"];
    
    NSString *tempStr2 = [tempStr1 stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
    
    NSString *tempStr3 = [[@"\"" stringByAppendingString:tempStr2] stringByAppendingString:@"\""];
    
    NSData *tempData = [tempStr3 dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString* returnStr = [NSPropertyListSerialization propertyListFromData:tempData
                           
                                                           mutabilityOption:NSPropertyListImmutable
                           
                                                                     format:NULL
                           
                                                           errorDescription:NULL];
    
    
    
    return [returnStr stringByReplacingOccurrencesOfString:@"\\r\\n" withString:@"\n"];
    
}



+(NSString *) utf8ToUnicode:(NSString *)string

{
    
    NSUInteger length = [string length];
    
    NSMutableString *s = [NSMutableString stringWithCapacity:0];
    
    for (int i = 0;i < length; i++)
        
    {
        
        unichar _char = [string characterAtIndex:i];
        
        //判断是否为英文和数字
        
        if (_char <= '9' && _char >= '0')
            
        {
            
            [s appendFormat:@"%@",[string substringWithRange:NSMakeRange(i, 1)]];
            
        }
        
        else if(_char >= 'a' && _char <= 'z')
            
        {
            
            [s appendFormat:@"%@",[string substringWithRange:NSMakeRange(i, 1)]];
            
            
            
        }
        
        else if(_char >= 'A' && _char <= 'Z')
            
        {
            
            [s appendFormat:@"%@",[string substringWithRange:NSMakeRange(i, 1)]];
            
            
            
        }
        
        else
            
        {
            
            [s appendFormat:@"\\u%x",[string characterAtIndex:i]];
            
        }
        
    }
    
    return s;
    
}



@end












