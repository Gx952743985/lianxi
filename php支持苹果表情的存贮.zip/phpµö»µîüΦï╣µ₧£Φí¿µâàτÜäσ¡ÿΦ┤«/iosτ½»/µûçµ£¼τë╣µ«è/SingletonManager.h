//
//  SingletonManager.h
//  Test_singleton_ARC
//
//  Created by SuperWang on 16/1/4.
//  Copyright (c) 2016年 智游. All rights reserved.
//
#import "AFNetworking.h"

//#import "SVProgressHUD.h"                   //加载框
//#import "UIImageView+WebCache.h"            //图片加载
//#import "UIButton+WebCache.h"
//#import "MJRefresh.h"                       //下拉刷新提示
//#import "LXAlertView.h"                     //断网提示框
//#import <Foundation/Foundation.h>
//#import "HDDefine.h"


typedef void (^CompletionBlock)(NSMutableDictionary *dic);

@interface SingletonManager : NSObject
/*!
 夜间模式  0是白 1是黑  !!注意这个是字符串
 */
@property(nonatomic,copy)NSString * nightDay ;//夜间模式  0是白 1是黑
/*!
 是否登录
 */
@property(nonatomic,assign) NSInteger isLogin;//登录
/*!
 是否有网络 0是没有 1是有网络
 */
@property(nonatomic,assign) NSInteger ISNoworking;
/*!
 刷新频率
 */
@property(nonatomic,copy)NSString * refreshed ;//刷新频率
/*!
 订阅是否储存
 */
@property(nonatomic,assign) NSInteger subscribeISNO;//订阅是否储存


+(SingletonManager*)sharedManager;
//****************************网络信息***************

+(NSString *) utf8ToUnicode:(NSString *)string;

/*!
  Unicode转UTF-8
 */
+ (NSString *)encodeToPercentEscapeString: (NSString *) input;
/*!
 UTF-8转Unicode
 */
+ (NSString*) replaceUnicode:(NSString*)aUnicodeString;

+ (NSString *)decodeFromPercentEscapeString: (NSString *) input;
/*!
 get请求
 */
+ (void)GXMenulisturl:(NSString*)urlstr completion:(CompletionBlock)cBlock;
/*!
 post 请求
 */
+(void)GXlistmessUrl:(NSString*)url  Winit:(NSDictionary*)dic  completion:(CompletionBlock)cBlock;


//****************************工具类***************

/*!
 感叹号提示
 */
+(void)GXmissnsting:(NSString*)str;
/*!
 开始刷新提示
 */
+(void)GXupdatamsiistr:(NSString*)str;

/*!
 结束结束提示
 */
+(void)GXendmsiistr;
/*! 正确提示 */
+(void)SuccessWithString:(NSString *)str ;
/*! 错误提示 */
+(void)ErrorWithString:(NSString *)str ;
/*!
 判断身份证
 */
+(BOOL)GXvalidateIdentityCard: (NSString *)identityCard;
/*!
 颜色识别
 */
+(UIColor*)initcolor:(NSString*)url;
/*!
 返回带**的手机号码
 */
+(NSString*)GXinitphoneStr:(NSString*)str;

@end
